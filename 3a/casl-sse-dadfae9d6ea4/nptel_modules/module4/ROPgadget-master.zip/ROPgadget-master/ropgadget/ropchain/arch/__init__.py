#!/usr/bin/env python2
## -*- coding: utf-8 -*-
##
##  Jonathan Salwan - 2014-05-13
##
##  http://shell-storm.org
##  http://twitter.com/JonathanSalwan
##

import ropgadget.ropchain.arch.ropmakerx86
import ropgadget.ropchain.arch.ropmakerx64
